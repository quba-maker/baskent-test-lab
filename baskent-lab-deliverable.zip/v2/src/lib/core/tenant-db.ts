import { logger } from "./logger";
import { sql as bypassSql } from "@/lib/db";
import { neon } from "@neondatabase/serverless";
import { TenantQueryGuard } from "../security/tenant-query-guard";

// ==========================================
// QUBA AI — Tenant-Aware DB Wrapper (RLS Enforced)
// Unsafe raw SQL'i engeller, tenant izolasyonunu DB seviyesinde garanti eder.
// ==========================================

const appDatabaseUrl = process.env.APP_DATABASE_URL || process.env.DATABASE_URL || "postgres://dummy:dummy@dummy.com/dummy";
const appSql = neon(appDatabaseUrl);

export class TenantDB {
  public readonly tenantId: string;
  private isAdmin: boolean;
  private log = logger.withContext({ module: 'TenantDB' });
  private sql = appSql;

  constructor(tenantId: string, isAdmin: boolean = false) {
    if (!tenantId) throw new Error("TenantDB instance requires a valid tenantId");
    this.tenantId = tenantId;
    this.isAdmin = isAdmin;
    this.log = this.log.withContext({ tenantId, isAdmin });
    if (isAdmin) {
      this.sql = bypassSql;
    }
  }

  /**
   * Güvenli raw query executor — RLS Context'i transaction içerisinde basar.
   * String interpolation yerine Parameterized Query'leri [query, params] formatında destekler.
   */
  async executeSafe(query: any, params?: any[]) {
    const startTime = Date.now();
    const safeTenantId = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(this.tenantId)
      ? this.tenantId
      : "00000000-0000-0000-0000-000000000000";
    
    try {
      if (!this.isAdmin) {
        if (typeof query === 'string') {
          TenantQueryGuard.assertTenantBoundQuery(this.tenantId, query, params || []);
        } else if (query && typeof query === 'object' && 'text' in query) {
          TenantQueryGuard.assertTenantBoundQuery(this.tenantId, query.text, query.values || []);
        }
      }

      // Neon HTTP Driver stateless'tır.
      // RLS context'inin kaybolmaması için, SET LOCAL sorgusunu 
      // asıl sorguyla beraber tek bir transaction batch'i olarak gönderiyoruz.
      // Postgres SET komutu parametre kabul etmediği için SELECT set_config() kullanıyoruz!
      const result = await this.sql.transaction(tx => {
        let actualQuery;
        if (typeof query === 'string') {
          actualQuery = tx.query(query, params || []);
        } else if (query && typeof query === 'object' && 'text' in query) {
          actualQuery = tx.query(query.text, query.values || []);
        } else {
          actualQuery = query;
        }

        return [
          this.isAdmin 
            ? tx`SELECT set_config('app.bypass_rls', 'true', true), set_config('app.current_tenant_id', ${safeTenantId}, true)`
            : tx`SELECT set_config('app.bypass_rls', 'false', true), set_config('app.current_tenant_id', ${safeTenantId}, true)`,
          actualQuery
        ];
      });
      
      const duration = Date.now() - startTime;
      if (duration > 1000) {
        this.log.warn(`🐢 Slow Query Detected`, { durationMs: duration });
      }
      
      // transaction array döndürür, bizim asıl sonucumuz 2. elemanda (index 1)
      return result[1];
    } catch (error: any) {
      this.log.error(`ExecuteSafe query failed (RLS Error?)`, error);
      throw error;
    }
  }

  /**
   * Çoklu query'leri aynı transaction (ve RLS context'i) içerisinde çalıştırır.
   * Lock'lar ve ardışık operasyonlar için kritik!
   */
  async executeTransaction(queries: any[]) {
    const startTime = Date.now();
    const safeTenantId = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(this.tenantId)
      ? this.tenantId
      : "00000000-0000-0000-0000-000000000000";

    try {
      const result = await this.sql.transaction(tx => {
        const formattedQueries = queries.map(q => {
          if (typeof q === 'string') {
            if (!this.isAdmin) {
              TenantQueryGuard.assertTenantBoundQuery(this.tenantId, q, []);
            }
            return tx.query(q);
          }
          if (Array.isArray(q) && q.length === 2 && typeof q[0] === 'string') {
            const [text, values] = q;
            if (!this.isAdmin) {
              TenantQueryGuard.assertTenantBoundQuery(this.tenantId, text, values || []);
            }
            return tx.query(text, values || []);
          }
          if (q && typeof q === 'object') {
            if ('text' in q) {
              if (!this.isAdmin) {
                TenantQueryGuard.assertTenantBoundQuery(this.tenantId, q.text, q.values || []);
              }
              return tx.query(q.text, q.values || []);
            }
            if ('query' in q) {
              const text = q.query;
              const values = q.params || q.values || [];
              if (!this.isAdmin) {
                TenantQueryGuard.assertTenantBoundQuery(this.tenantId, text, values);
              }
              return tx.query(text, values);
            }
          }
          return q;
        });

        return [
          this.isAdmin 
            ? tx`SELECT set_config('app.bypass_rls', 'true', true), set_config('app.current_tenant_id', ${safeTenantId}, true)`
            : tx`SELECT set_config('app.bypass_rls', 'false', true), set_config('app.current_tenant_id', ${safeTenantId}, true)`,
          ...formattedQueries
        ];
      });
      const duration = Date.now() - startTime;
      if (duration > 2000) {
        this.log.warn(`🐢 Slow Transaction Detected`, { durationMs: duration });
      }
      return result.slice(1);
    } catch (error: any) {
      this.log.error(`ExecuteTransaction failed`, error);
      throw error;
    }
  }
}

// Global olarak çağrılacak factory
export function withTenantDB(tenantId: string, isAdmin: boolean = false) {
  return new TenantDB(tenantId, isAdmin);
}

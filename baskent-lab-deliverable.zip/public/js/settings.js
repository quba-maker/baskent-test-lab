/* AYARLAR & ETİKETLER */
async function loadSettings() {
  const s = await api('settings'); if(!s) return;
  document.getElementById('model-select').value = s.ai_model || 'gemini-2.5-flash-lite';
  allTags = await api('tags') || [];
  document.getElementById('tag-list').innerHTML = allTags.map(t => 
    `<div style="display:flex; justify-content:space-between; padding:12px; background:var(--bg-hover); border-radius:var(--radius-sm);">
      <span style="color:${t.color}; font-weight:600;">${t.name}</span>
      <button class="btn-sm btn-danger" onclick="deleteTag(${t.id})">Sil</button>
    </div>`
  ).join('');
  
  // Kanal toggle durumlarını yükle (varsayılan: WA açık, IG ve Messenger kapalı)
  document.getElementById('toggle-whatsapp').checked = (s.channel_whatsapp_enabled || 'true') === 'true';
  document.getElementById('toggle-instagram').checked = (s.channel_instagram_enabled || 'false') === 'true';
  document.getElementById('toggle-messenger').checked = (s.channel_messenger_enabled || 'false') === 'true';
  
  // Form karşılama mesajlarını yükle
  document.getElementById('form-greeting-tr').value = s.form_greeting_tr || '';
  document.getElementById('form-greeting-en').value = s.form_greeting_en || '';
  
  // Teklif şablonu ayarlarını yükle
  document.getElementById('qt-hospital-name').value = s.qt_hospital_name || '';
  document.getElementById('qt-hospital-subtitle').value = s.qt_hospital_subtitle || '';
  document.getElementById('qt-intro-text').value = s.qt_intro_text || '';
  document.getElementById('qt-footer-note').value = s.qt_footer_note || '';
  document.getElementById('qt-footer-address').value = s.qt_footer_address || '';
  document.getElementById('qt-validity-days').value = s.qt_validity_days || '30';
  document.getElementById('qt-wa-message').value = s.qt_wa_message || '';
}

async function saveModel() {
  const model = document.getElementById('model-select').value;
  await api('settings', 'POST', { key: 'ai_model', value: model });
  toast('Yapay Zeka Modeli güncellendi ✅');
}

async function saveChannelToggle(channel, enabled) {
  const key = `channel_${channel}_enabled`;
  const value = enabled ? 'true' : 'false';
  await api('settings', 'POST', { key, value });
  const labels = { whatsapp: 'WhatsApp', instagram: 'Instagram', messenger: 'Messenger' };
  const emoji = enabled ? '✅' : '⛔';
  toast(`${emoji} ${labels[channel]} botu ${enabled ? 'AKTİF' : 'PASİF'} yapıldı`);
}
async function addTag() {
  await api('tags','POST',{name:document.getElementById('new-tag').value, color:document.getElementById('new-tag-color').value});
  document.getElementById('new-tag').value=''; loadSettings();
}
async function deleteTag(id) { await api('tags&id='+id,'DELETE'); loadSettings(); }

async function saveFormGreetings() {
  const tr = document.getElementById('form-greeting-tr').value;
  const en = document.getElementById('form-greeting-en').value;
  await api('settings','POST',{key:'form_greeting_tr', value: tr});
  await api('settings','POST',{key:'form_greeting_en', value: en});
  toast('Form karşılama mesajları kaydedildi ✅');
}

async function saveQuoteTemplate() {
  const fields = [
    ['qt_hospital_name', 'qt-hospital-name'],
    ['qt_hospital_subtitle', 'qt-hospital-subtitle'],
    ['qt_intro_text', 'qt-intro-text'],
    ['qt_footer_note', 'qt-footer-note'],
    ['qt_footer_address', 'qt-footer-address'],
    ['qt_validity_days', 'qt-validity-days'],
    ['qt_wa_message', 'qt-wa-message']
  ];
  for (const [key, id] of fields) {
    await api('settings', 'POST', { key, value: document.getElementById(id).value });
  }
  toast('Teklif şablonu kaydedildi ✅');
}

let calendarEventsData = [];
let selectedAptId = null;
let aptFilterMode = 'all';

// switchAptTab removed — Calendar tab was removed from HTML, single-view CRM now

function filterAptList(mode) {
  aptFilterMode = mode;
  renderAptList();
}

function renderAptList() {
  let filtered = calendarEventsData;
  if (aptFilterMode !== 'all') {
    if (aptFilterMode === 'contacted') filtered = calendarEventsData.filter(e => ['called','contacted'].includes(e.status));
    else if (aptFilterMode === 'scheduled') filtered = calendarEventsData.filter(e => ['scheduled','confirmed'].includes(e.status));
    else if (aptFilterMode === 'completed') filtered = calendarEventsData.filter(e => ['completed'].includes(e.status));
    else if (aptFilterMode === 'lost') filtered = calendarEventsData.filter(e => ['lost','cancelled','noshow'].includes(e.status));
    else filtered = calendarEventsData.filter(e => e.status === aptFilterMode);
  }
  
  const list = document.getElementById('appointment-list');
  if (filtered.length === 0) { list.innerHTML = '<div class="empty" style="padding:30px"><div class="empty-icon">📥</div>Talep yok</div>'; return; }
  
  const sC = {pending:'#f59e0b',called:'#3b82f6',scheduled:'#22c55e',confirmed:'#22c55e',lost:'#6b7280',cancelled:'#6b7280',completed:'#8b5cf6',noshow:'#ef4444'};
  const sL = {pending:'⏳ Bekliyor',called:'📞 Arandı',scheduled:'📅 Takvimde',confirmed:'✅ Onaylı',lost:'❌ Olumsuz',cancelled:'🚫 İptal',completed:'🏥 Tamamlandı',noshow:'❌ Gelmedi'};
  
  list.innerHTML = filtered.map(e => {
    const nm = e.patient_name || e.phone_number;
    const dt = new Date(e.created_at).toLocaleString('tr-TR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'});
    const active = selectedAptId === e.id ? 'border-right:3px solid var(--accent-primary);background:rgba(99,102,241,0.08);' : '';
    const schedDate = e.scheduled_date ? new Date(e.scheduled_date).toLocaleString('tr-TR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}) : '';
    return `<div onclick="loadAptDetail(${e.id})" style="padding:10px 12px;background:var(--bg-hover);border-radius:10px;margin-bottom:6px;cursor:pointer;border-left:3px solid ${sC[e.status]||'#6b7280'};transition:all 0.15s;${active}" onmouseover="this.style.opacity='0.85'" onmouseout="this.style.opacity='1'">
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <span style="font-weight:600;font-size:13px;">${escapeHtml(nm)}</span>
        <span style="font-size:10px;color:${sC[e.status]};font-weight:600;">${sL[e.status]||e.status}</span>
      </div>
      <div style="display:flex;gap:8px;margin-top:4px;flex-wrap:wrap;">
        ${e.department?`<span style="font-size:10px;background:var(--accent-primary);color:white;padding:1px 6px;border-radius:4px;">🩺 ${e.department}</span>`:''}
        ${e.city?`<span style="font-size:10px;color:var(--text-muted);">📍 ${escapeHtml(e.city)}</span>`:''}
        ${schedDate?`<span style="font-size:10px;color:#22c55e;">📅 ${schedDate}</span>`:`<span style="font-size:10px;color:var(--text-muted);">🕐 ${dt}</span>`}
      </div>
    </div>`;
  }).join('');
}

async function loadAppointments() {
  const data = await api('appointments');
  if (!data) return;
  calendarEventsData = data.events || [];
  
  const c = data.counts || {};
  const completed = calendarEventsData.filter(e => e.status === 'completed').length;
  
  // Safely update legacy stat pills if they exist
  ['apt-total','apt-pending','apt-called','apt-scheduled-count','apt-completed','apt-lost'].forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      if (id === 'apt-total') el.textContent = calendarEventsData.length;
      if (id === 'apt-pending') el.textContent = c.pending || 0;
      if (id === 'apt-called') el.textContent = c.called || 0;
      if (id === 'apt-scheduled-count') el.textContent = c.scheduled || 0;
      if (id === 'apt-completed') el.textContent = completed;
      if (id === 'apt-lost') el.textContent = c.lost || 0;
    }
  });
  
  const badge = document.getElementById('apt-badge');
  if (badge) {
    if ((c.pending||0) > 0) { badge.textContent = c.pending; badge.style.display = 'inline'; }
    else { badge.style.display = 'none'; }
  }
  
  renderAptList();
  if (typeof filterCalendar === 'function') filterCalendar();
}

async function loadAptDetail(eventId) {
  selectedAptId = eventId;
  renderAptList();
  
  if (window.innerWidth <= 768) navigateMobileAptView('detail');
  
  const panel = document.getElementById('apt-detail-content');
  panel.innerHTML = '<div style="padding:20px;display:flex;flex-direction:column;gap:16px;"><div class="skeleton skeleton-text" style="width:60%;height:24px;"></div><div class="skeleton skeleton-text short"></div><div class="skeleton skeleton-card" style="height:100px;"></div><div class="skeleton skeleton-card" style="height:200px;"></div></div>';
  
  const data = await api('appointment-detail&id=' + eventId);
  if (!data || !data.event) { panel.innerHTML = '<div class="empty">Detay yüklenemedi</div>'; return; }
  
  const e = data.event;
  const msgs = data.messages || [];
  const reminders = data.reminders || [];
  const nm = e.patient_name || e.phone_number;
  
  // 1. Pipeline Mantığı (4 Aşama)
  const statusMap = {
    'pending': 'pending',
    'called': 'contacted', 'contacted': 'contacted',
    'scheduled': 'scheduled', 'confirmed': 'scheduled',
    'completed': 'closed', 'noshow': 'closed', 'lost': 'closed', 'cancelled': 'closed', 'closed': 'closed'
  };
  const currentStage = statusMap[e.status] || 'pending';
  
  const stages = [
    {key:'pending', icon:'⏳', label:'Bekliyor', color:'#FF9F0A'},
    {key:'contacted', icon:'📞', label:'İletişimde', color:'#0A84FF'},
    {key:'scheduled', icon:'📅', label:'Takvimde', color:'#30D158'},
    {key:'closed', icon:'🏁', label:'Sonuçlandı', color:'#BF5AF2'}
  ];
  
  const pipelineHtml = `
    <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); border-radius:16px; padding:16px; margin-bottom:16px;">
      <div style="font-size:11px; font-weight:600; color:var(--text-muted); text-transform:uppercase; margin-bottom:12px; letter-spacing:0.5px;">🎯 İşlem Aşaması</div>
      <div style="display:flex; gap:8px; overflow-x:auto; padding-bottom:4px;">
        ${stages.map(s => {
          const isActive = s.key === currentStage;
          const bg = isActive ? \`rgba(\${hexToRgb(s.color)}, 0.15)\` : 'rgba(0,0,0,0.2)';
          const border = isActive ? s.color : 'rgba(255,255,255,0.05)';
          const color = isActive ? s.color : 'var(--text-muted)';
          return \`<button onclick="updateAppointment(\${e.id},'\${s.key}')" style="flex:1; min-width:100px; display:flex; flex-direction:column; align-items:center; gap:6px; padding:10px; border-radius:12px; border:1px solid \${border}; background:\${bg}; color:\${color}; cursor:pointer; transition:all 0.2s;">
            <span style="font-size:18px;">\${s.icon}</span>
            <span style="font-size:12px; font-weight:600;">\${s.label}</span>
          </button>\`;
        }).join('')}
      </div>
    </div>
  `;

  // 2. Apple Takvim Kartı (Sadece Takvimde veya Sonuçlandı ise)
  let scheduleHtml = '';
  if (['scheduled', 'closed'].includes(currentStage)) {
    const tzOffset = (new Date()).getTimezoneOffset() * 60000;
    const localISOTime = e.scheduled_date ? (new Date(new Date(e.scheduled_date) - tzOffset)).toISOString().slice(0, 16) : '';
    
    let showUpHtml = '';
    if (e.showed_up === true) {
      showUpHtml = \`<div style="margin-top:12px; padding:10px; background:rgba(48,209,88,0.1); border:1px solid rgba(48,209,88,0.2); border-radius:10px; text-align:center; font-size:13px; color:#30D158; font-weight:600;">✅ Hasta Geldi \${e.treatment_completed ? '(Tedavi Tamamlandı)' : ''}</div>\`;
    } else if (e.showed_up === false) {
      showUpHtml = \`<div style="margin-top:12px; padding:10px; background:rgba(255,69,58,0.1); border:1px solid rgba(255,69,58,0.2); border-radius:10px; text-align:center; font-size:13px; color:#FF453A; font-weight:600;">❌ Hasta Gelmedi \${e.no_show_reason ? ' — ' + e.no_show_reason : ''}</div>\`;
    } else {
      showUpHtml = \`<div style="display:flex; gap:8px; margin-top:12px;">
        <button onclick="markShowUp(\${e.id},true)" style="flex:1; padding:10px; border-radius:10px; border:none; background:rgba(48,209,88,0.15); color:#30D158; font-size:13px; font-weight:600; cursor:pointer;">✅ Geldi</button>
        <button onclick="markShowUp(\${e.id},false)" style="flex:1; padding:10px; border-radius:10px; border:none; background:rgba(255,69,58,0.15); color:#FF453A; font-size:13px; font-weight:600; cursor:pointer;">❌ Gelmedi</button>
      </div>\`;
    }

    scheduleHtml = \`
      <div style="background:linear-gradient(145deg, rgba(48,209,88,0.05), rgba(0,0,0,0.2)); border:1px solid rgba(48,209,88,0.2); border-radius:16px; padding:20px; margin-bottom:16px; box-shadow:0 8px 24px rgba(0,0,0,0.2);">
        <div style="display:flex; align-items:center; gap:10px; margin-bottom:16px;">
          <div style="width:36px; height:36px; background:rgba(48,209,88,0.2); border-radius:10px; display:flex; align-items:center; justify-content:center; font-size:18px;">📅</div>
          <div>
            <div style="font-size:15px; font-weight:600; color:white;">Randevu Planı</div>
            <div style="font-size:11px; color:var(--text-muted);">Tarih ve doktor bilgisi</div>
          </div>
        </div>
        
        <div style="display:flex; flex-direction:column; gap:12px;">
          <div>
            <label style="font-size:11px; color:var(--text-muted); display:block; margin-bottom:4px;">Tarih & Saat</label>
            <input type="datetime-local" id="apt-date-input" value="\${localISOTime}" onchange="updateAppointmentDateInline(\${e.id}, this.value)" style="width:100%; background:rgba(0,0,0,0.3); border:1px solid rgba(255,255,255,0.1); color:#30D158; padding:12px; border-radius:10px; font-size:14px; font-weight:600; color-scheme:dark; outline:none;">
          </div>
          <div>
            <label style="font-size:11px; color:var(--text-muted); display:block; margin-bottom:4px;">Doktor / Uzman</label>
            <div style="display:flex; gap:8px;">
              <input type="text" id="apt-doctor-input" placeholder="Örn: Dr. Ahmet Yılmaz" value="\${e.assigned_doctor||''}" style="flex:1; background:rgba(0,0,0,0.3); border:1px solid rgba(255,255,255,0.1); color:white; padding:12px; border-radius:10px; font-size:13px; outline:none;">
              <button onclick="api('update-appointment','POST',{id:\${e.id}, assigned_doctor:document.getElementById('apt-doctor-input').value});toast('Doktor güncellendi')" style="background:rgba(255,255,255,0.1); border:none; border-radius:10px; padding:0 16px; color:white; font-weight:600; cursor:pointer;">Kaydet</button>
            </div>
          </div>
        </div>
        \${showUpHtml}
      </div>
    \`;
  }

  // 3. Birleşik Timeline (Form + Not + Mesajlar + Hatırlatmalar)
  let timelineItems = [];
  
  // Form Verisi
  try {
    const raw = typeof e.raw_data === 'string' ? JSON.parse(e.raw_data || '{}') : (e.raw_data || {});
    const skip = ['id','leadgen_id','form_id','ad_id','adset_id','campaign_id','platform','is_organic','created_time','phone_number_id','full_name','phone_number'];
    const entries = Object.entries(raw).filter(([k]) => !skip.includes(k.toLowerCase()));
    if (entries.length > 0) {
      let fHtml = entries.map(([k,v]) => \`<div style="display:flex; justify-content:space-between; padding:4px 0; border-bottom:1px solid rgba(255,255,255,0.05); gap:12px;">
        <span style="font-size:11px; color:var(--text-muted); text-transform:uppercase;">\${escapeHtml(k.replace(/_/g,' '))}</span>
        <span style="font-size:12px; font-weight:500; color:white; text-align:right; word-break:break-word;">\${escapeHtml(String(v||'').replace(/_/g,' '))}</span>
      </div>\`).join('');
      timelineItems.push({
        type: 'form', date: new Date(e.created_at || Date.now()),
        html: \`<div style="background:rgba(10,132,255,0.05); border:1px solid rgba(10,132,255,0.2); border-radius:12px; padding:12px;">
          <div style="font-size:12px; font-weight:600; color:#0A84FF; margin-bottom:8px; display:flex; align-items:center; gap:6px;">📋 Form Dolduruldu</div>
          \${fHtml}
        </div>\`
      });
    }
  } catch(err) {}

  // Mesajlar
  msgs.forEach(m => {
    const isOut = m.direction === 'out';
    const content = escapeHtml(m.content || '');
    timelineItems.push({
      type: 'message', date: new Date(m.created_at),
      html: \`<div style="background:\${isOut ? 'rgba(99,102,241,0.08)' : 'rgba(255,255,255,0.03)'}; border-left:3px solid \${isOut ? 'var(--accent-primary)' : '#FF9F0A'}; border-radius:0 12px 12px 0; padding:10px 12px;">
        <div style="font-size:10px; color:var(--text-muted); margin-bottom:4px; font-weight:600;">\${isOut ? (m.model_used==='panel' ? '👤 Operatör' : '🤖 Yapay Zeka') : '📩 Hasta'}</div>
        <div style="font-size:13px; line-height:1.4; color:white; word-break:break-word;">\${content}</div>
      </div>\`
    });
  });

  // Hatırlatmalar
  reminders.forEach(r => {
    timelineItems.push({
      type: 'reminder', date: new Date(r.created_at),
      html: \`<div style="background:rgba(48,209,88,0.05); border:1px dashed rgba(48,209,88,0.3); border-radius:12px; padding:10px 12px; display:flex; align-items:center; gap:8px;">
        <span style="font-size:16px;">🔔</span>
        <div>
          <div style="font-size:12px; font-weight:600; color:#30D158;">Otomatik Hatırlatma Gönderildi</div>
          <div style="font-size:11px; color:var(--text-muted);">\${escapeHtml(r.content || 'Sistem mesajı')}</div>
        </div>
      </div>\`
    });
  });

  // Sort timeline chronological (newest first)
  timelineItems.sort((a,b) => b.date - a.date);
  
  const timelineHtml = \`
    <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); border-radius:16px; padding:20px;">
      <h3 style="margin:0 0 16px 0; font-size:15px; color:white; font-weight:600; display:flex; align-items:center; gap:8px;">
        <span style="background:rgba(255,159,10,0.15); color:#FF9F0A; width:28px; height:28px; border-radius:8px; display:flex; align-items:center; justify-content:center; font-size:14px;">🕰️</span>
        Hasta Geçmişi
      </h3>
      
      <!-- Koordinatör Notu Hızlı Ekleme -->
      <div style="display:flex; gap:8px; margin-bottom:20px;">
        <input type="text" id="apt-coord-note" placeholder="Not ekle..." value="\${escapeHtml(e.coordinator_notes||'')}" style="flex:1; background:rgba(0,0,0,0.2); border:1px solid rgba(255,255,255,0.1); padding:10px 14px; border-radius:10px; color:white; font-size:13px; outline:none;">
        <button onclick="saveCoordNote(\${e.id})" style="background:var(--accent-primary); color:white; border:none; border-radius:10px; padding:0 16px; font-weight:600; cursor:pointer;">Kaydet</button>
      </div>

      <div class="unified-timeline" style="display:flex; flex-direction:column; gap:16px; position:relative; padding-left:12px; border-left:2px solid rgba(255,255,255,0.05);">
        \${timelineItems.length > 0 ? timelineItems.map(item => \`
          <div style="position:relative;">
            <div style="position:absolute; left:-17px; top:12px; width:10px; height:10px; border-radius:50%; background:var(--bg-main); border:2px solid rgba(255,255,255,0.2);"></div>
            <div style="font-size:10px; color:var(--text-muted); margin-bottom:4px; padding-left:4px;">\${item.date.toLocaleString('tr-TR',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'})}</div>
            \${item.html}
          </div>
        \`).join('') : '<div style="font-size:13px; color:var(--text-muted); text-align:center; padding:20px;">Geçmiş kaydı bulunamadı.</div>'}
      </div>
    </div>
  \`;

  panel.innerHTML = \`
    <div style="padding:24px; display:flex; flex-direction:column; max-width:800px; margin:0 auto; width:100%;">
      
      <!-- Header -->
      <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:24px;">
        <div style="display:flex; align-items:center; gap:12px;">
          <button class="mobile-only-btn btn-back" onclick="navigateMobileAptView('list')" style="width:36px; height:36px; background:rgba(255,255,255,0.05); border:none; border-radius:10px; color:white; font-size:20px; display:flex; align-items:center; justify-content:center; cursor:pointer;">‹</button>
          <div>
            <div style="font-size:24px; font-weight:700; color:white; letter-spacing:-0.5px;">\${escapeHtml(nm)}</div>
            <div style="display:flex; gap:12px; margin-top:6px; flex-wrap:wrap; align-items:center;">
              <span style="font-size:13px; color:var(--text-muted); display:flex; align-items:center; gap:4px;">📱 \${escapeHtml(e.phone_number)}</span>
              \${e.department ? \`<span style="font-size:11px; background:rgba(10,132,255,0.1); color:#0A84FF; padding:3px 8px; border-radius:6px; font-weight:600;">\${e.department}</span>\` : ''}
              \${e.city ? \`<span style="font-size:12px; color:var(--text-muted);">📍 \${escapeHtml(e.city)}</span>\` : ''}
            </div>
          </div>
        </div>
        <div style="display:flex; gap:8px;">
          <button onclick="window.open('https://wa.me/\${e.phone_number.replace(/[^0-9]/g,'')}','_blank')" style="padding:8px 14px; border-radius:10px; border:none; background:rgba(37,211,102,0.15); color:#25D366; cursor:pointer; font-size:13px; font-weight:600; display:flex; align-items:center; gap:6px;">WhatsApp</button>
          <button onclick="document.querySelector('[data-page=conversations]').click();setTimeout(()=>loadChat('\${e.phone_number}','whatsapp'),300)" style="padding:8px 14px; border-radius:10px; border:1px solid rgba(255,255,255,0.1); background:rgba(255,255,255,0.05); color:white; cursor:pointer; font-size:13px; font-weight:500; display:flex; align-items:center; gap:6px;">💬 Sohbet</button>
        </div>
      </div>
      
      \${pipelineHtml}
      \${scheduleHtml}
      \${timelineHtml}
      
    </div>
  \`;
}

function hexToRgb(hex) {
  var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? parseInt(result[1], 16) + ',' + parseInt(result[2], 16) + ',' + parseInt(result[3], 16) : '255,255,255';
}
  

async function saveCoordNote(id) {
  const note = document.getElementById('apt-coord-note').value;
  await api('update-appointment','POST',{id, coordinator_notes: note});
  showNotification('Koordinatör notu kaydedildi ✅', 'success');
}

async function saveAptDate(id) {
  const dt = document.getElementById('apt-date-input').value;
  const doctor = document.getElementById('apt-doctor-input')?.value || '';
  if (!dt) return toast('Lütfen bir tarih seçin', 'error');
  
  const d = new Date(dt);
  await api('update-appointment', 'POST', { id, scheduled_date: d.toISOString(), status: 'scheduled', assigned_doctor: doctor || null });
  toast('📅 Randevu kaydedildi ✅');
  loadAppointments();
  loadAptDetail(id);
}

function downloadIcal(id) {
  window.open(`/api/panel?action=appointment-ical&id=${id}`, '_blank');
}

// setCalendarFilter and filterCalendar removed — Calendar tab was removed from HTML
// Calendar functionality is now handled within the CRM pipeline detail view

async function updateAppointment(id, stage) {
  if (!stage) return;
  // Map UI pipeline stages to DB-compatible status values
  const stageToStatus = { pending: 'pending', contacted: 'called', scheduled: 'scheduled', closed: 'completed' };
  const dbStatus = stageToStatus[stage] || stage;
  await api('update-appointment', 'POST', { id, status: dbStatus });
  loadAppointments();
  if (selectedAptId === id) loadAptDetail(id);
  toast('Durum güncellendi ✅');
}

async function markShowUp(id, showedUp) {
  if (showedUp === true) { await api('update-showup','POST',{id,showed_up:true}); toast('✅ Hasta geldi'); }
  else if (showedUp === false) { const r = prompt('Gelmeme nedeni (opsiyonel):') || 'Bilinmiyor'; await api('update-showup','POST',{id,showed_up:false,no_show_reason:r}); toast('❌ No-show'); }
  else { await api('update-showup','POST',{id,showed_up:null}); toast('🔄 Durum sıfırlandı'); }
  loadAppointments();
}

async function markTreatmentDone(id) {
  const s = parseInt(prompt('Memnuniyet puanı (1-5):')||'0');
  await api('update-showup','POST',{id,showed_up:true,treatment_completed:true,satisfaction_score:(s>=1&&s<=5)?s:null});
  toast('🏥 Tedavi tamamlandı'); loadAppointments();
}

async function updateAppointmentDateInline(id, localTimeStr) {
  if (!localTimeStr) return;
  const d = new Date(localTimeStr);
  await api('update-appointment', 'POST', { id, scheduled_date: d.toISOString(), status: 'scheduled' });
  toast('📅 Randevu tarihi güncellendi');
  loadAppointments();
}

// ========== BİLDİRİM SİSTEMİ ==========
async function checkNotifications() {
  try {
    const data = await api('notifications');
    if (!data) return;
    const bell = document.getElementById('notif-bell');
    const count = document.getElementById('notif-count');
    if (data.total > 0) { bell.style.display = 'flex'; count.textContent = data.total; }
    else { bell.style.display = 'none'; }
    const badge = document.getElementById('apt-badge');
    if (data.pendingAppointments > 0) { badge.textContent = data.pendingAppointments; badge.style.display = 'inline'; }
  } catch(e) {}
}
function showNotifications() {
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  document.querySelector('[data-page="appointments"]').classList.add('active');
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById('page-appointments').classList.add('active');
  loadAppointments();
}

// ========== GELİŞMİŞ ANALİTİK ==========
async function loadAdvancedAnalytics() {
  const data = await api('advanced-analytics');
  if (!data) return;
  let cHtml = '<table style="width:100%;font-size:13px;border-collapse:collapse"><tr style="border-bottom:1px solid var(--border-color)"><th style="text-align:left;padding:8px">Kampanya</th><th>Lead</th><th>Cevap</th><th>Randevu</th><th>Dönüşüm</th></tr>';
  (data.campaignConversion||[]).forEach(c => {
    const rate = c.total > 0 ? Math.round((Number(c.appointed)/Number(c.total))*100) : 0;
    const cl = rate>20?'#22c55e':rate>10?'#f59e0b':'#ef4444';
    cHtml += `<tr style="border-bottom:1px solid rgba(255,255,255,0.05)"><td style="padding:6px 8px;max-width:200px;overflow:hidden;text-overflow:ellipsis">${c.form_name}</td><td style="text-align:center">${c.total}</td><td style="text-align:center">${c.responded}</td><td style="text-align:center">${c.appointed}</td><td style="text-align:center;color:${cl};font-weight:600">${rate}%</td></tr>`;
  });
  cHtml += '</table>';
  const el = document.getElementById('advanced-analytics-content');
  if (el) el.innerHTML = `
    <div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:20px">
      <div class="stat-card"><div class="stat-value" style="color:#3b82f6">${data.botMessages}</div><div class="stat-label">🤖 Bot Mesajı</div></div>
      <div class="stat-card"><div class="stat-value" style="color:#8b5cf6">${data.humanMessages}</div><div class="stat-label">👤 Personel Mesajı</div></div>
      <div class="stat-card"><div class="stat-value" style="color:#22c55e">${data.intlPatients}/${data.totalPatients}</div><div class="stat-label">🌍 Uluslararası</div></div>
      <div class="stat-card"><div class="stat-value" style="color:#f59e0b">${data.avgResponseSeconds>0?Math.round(data.avgResponseSeconds)+'s':'—'}</div><div class="stat-label">⚡ Ort. Yanıt</div></div>
    </div>
    <div class="stats-grid" style="grid-template-columns:1fr 1fr">
      <div class="card"><h2>📊 Kampanya Dönüşüm</h2>${cHtml}</div>
      <div class="card"><h2>🏥 Bölüm Talep Dağılımı</h2>${(data.departmentDemand||[]).map(d=>
        `<div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid rgba(255,255,255,0.05)"><span style="font-size:13px">${d.name}</span><div style="display:flex;align-items:center;gap:8px"><div style="width:${Math.min(d.count*15,200)}px;height:8px;background:linear-gradient(90deg,#3b82f6,#8b5cf6);border-radius:4px"></div><span style="font-size:12px;font-weight:600;min-width:24px;text-align:right">${d.count}</span></div></div>`
      ).join('')}</div>
    </div>`;
}

// Başlatıcı
checkAuth();

// Otomatik yenileme + bildirim (8 saniyede bir)
setInterval(async () => {
  const page = document.querySelector('.page.active')?.id;
  // Komuta Merkezi polling'den çıkarıldı — analitik sorguları ağır, manuel yenileme yeterli
  // loadKanban kaldırıldı — pipeline filtreleri inbox'ta
  if (page === 'page-appointments') loadAppointments();
  if (page === 'page-conversations' && currentPhone) {
    const msgs = await api('conversation-detail&phone=' + currentPhone);
    if (!msgs) return;
    const chatEl = document.getElementById('chat-messages');
    const currentCount = chatEl.querySelectorAll('.message-bubble').length;
    if (msgs.length > currentCount) loadChat(currentPhone, currentChannel);
  }
  checkNotifications();
  fetchZorbayAlerts();
}, 8000);

// ========== ZORBAY ALERT SİSTEMİ ==========
async function fetchZorbayAlerts() {
  try {
    const alerts = await api('alerts');
    if (!alerts || !alerts.length) return;
    
    // Yalnızca ekranda olmayanları ekle
    alerts.forEach(alert => {
      // Bildirim zili paneline (soldaki menüye) ekle
      const titleText = alert.alert_type === 'hot_lead' ? '🔥 Sıcak Lead (Manuel)' : alert.alert_type === 'new_image' ? '📸 Görüntü/Rapor' : '🚨 CRM Uyarısı';
      const sev = alert.alert_type === 'hot_lead' ? 'critical' : 'warning';
      
      const allNotifs = _notifStore.getAll();
      const exists = allNotifs.find(n => n.dbId === alert.id);
      
      if (!exists) {
        _notifStore.add({
          title: titleText,
          desc: alert.message,
          severity: sev,
          icon: '🚨',
          phone: alert.phone_number,
          dbId: alert.id
        });
        updateNotifBadge();
        
        // Sesi çal (Kullanıcı etkileşimi olduysa çalar)
        try { new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3').play(); } catch(e){}
      }
    });
  } catch (e) { console.error('Alert fetch error', e); }
}

// =========================================================================
// REAL-TIME SWR POLLING (Vercel Serverless Optimizasyonu)
// =========================================================================
let pollInterval = null;
function startPolling() {
  if (pollInterval) clearInterval(pollInterval);
  
  pollInterval = setInterval(async () => {
    // Sadece sekme açıkken ve kullanıcı uygulamaya bakıyorken istek at (Vercel tasarrufu)
    if (document.visibilityState !== 'visible') return;
    
    const activePage = document.querySelector('.nav-btn.active')?.dataset?.page;
    
    if (activePage === 'conversations') {
      // 1. Sol paneli güncelle (Contact List)
      const list = await api('conversations', 'GET', null, true); // true = sessiz (hata gösterme)
      if (list && JSON.stringify(list) !== JSON.stringify(cachedConversations)) {
        cachedConversations = list;
        renderConversationList();
      }
      
      // 2. Açık olan mesajlaşmayı güncelle
      if (currentPhone) {
        const data = await api('conversation-detail&phone='+currentPhone, 'GET', null, true);
        if (data) {
          const msgs = data.messages || data;
          const chatEl = document.getElementById('chat-messages');
          
          if (chatEl && msgs.length !== lastChatLength) {
            // Scroll en altta mı kontrol et
            const isScrolledToBottom = chatEl.scrollHeight - chatEl.clientHeight <= chatEl.scrollTop + 50;
            
            chatEl.innerHTML = msgs.map(m => {
              const isOut = m.direction === 'out';
              const isBot = m.model_used && m.model_used !== 'panel' && m.model_used !== 'toplu';
              const cls = `message-bubble ${isOut ? 'out' : 'in'} ${isOut && isBot ? 'bot-reply' : ''}`;
              const senderLabel = isOut ? (isBot ? '🤖 Bot' : '👤 Sen') : '📩 Hasta';
              const info = `<div class="msg-info">${senderLabel} · ${new Date(m.created_at).toLocaleTimeString('tr-TR', {hour:'2-digit',minute:'2-digit'})} ${isBot ? '<span class="bot-indicator">' + m.model_used + '</span>' : ''}</div>`;
              
              let content = m.content;
              if (m.media_url) {
                if (m.media_type === 'image') content = `<img src="${m.media_url}" style="max-width:240px;border-radius:8px;margin-bottom:4px;"><br>${m.content||''}`;
                else content = `📎 <a href="${m.media_url}" target="_blank" style="color:inherit;text-decoration:underline">${m.content||'Dosya'}</a>`;
              }
              return `<div class="${cls}">${content}${info}</div>`;
            }).join('');
            
            // Eğer yeni mesaj geldiyse veya önceden alttaysa scrollu en alta çek
            if (isScrolledToBottom || msgs.length > lastChatLength) {
              chatEl.scrollTop = chatEl.scrollHeight;
              
              // Sesli bildirim (Opsiyonel ama premium bir his verir)
              if (msgs.length > lastChatLength && msgs[msgs.length - 1].direction === 'in') {
                try { new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3').play(); } catch(e) {}
              }
            }
            lastChatLength = msgs.length;
          }
        }
      }
    }
  }, 3000); // 3 saniyede bir kontrol et
}

async function dismissZorbayAlert(id, phone) {
  const el = document.getElementById('zorbay-alert-' + id);
  if (el) el.remove();
  await api('mark-alert-read', 'POST', { id });
}

